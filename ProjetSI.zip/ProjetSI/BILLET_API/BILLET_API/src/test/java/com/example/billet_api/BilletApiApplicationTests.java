package com.example.billet_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BilletApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
