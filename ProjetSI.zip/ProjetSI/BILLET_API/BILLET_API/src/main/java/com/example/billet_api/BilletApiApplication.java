package com.example.billet_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BilletApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BilletApiApplication.class, args);
    }

}
