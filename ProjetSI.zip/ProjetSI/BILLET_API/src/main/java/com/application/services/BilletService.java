package com.application.services;

import com.application.dtos.BilletDto;
import com.application.entities.Billet;
import com.application.repositories.BilletRepository;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class BilletService {

    private final BilletRepository billetRepository;

    public BilletService(BilletRepository billetRepository) {
        this.billetRepository = billetRepository;
    }

    public BilletDto create(BilletDto billetDto) {
        Billet billet = new Billet();
        billet.setNom(billetDto.getNom());
        billet.setPrenom(billetDto.getPrenom());
        billet.setSoiId(billetDto.getSoiId());
        billetRepository.save(billet);
        billetDto.setId(billet.getId());
        return billetDto;
    }

    public BilletDto findById(Long id) {
        Optional<Billet> billetOptional = billetRepository.findById(id);
        if (billetOptional.isPresent()) {
            Billet billet = billetOptional.get();
            return new BilletDto(billet.getId(), billet.getNom(), billet.getPrenom(), billet.getSoiId());
        } else {
            throw new EntityNotFoundException("Billet not found with id " + id);
        }
    }

    public List<BilletDto> findAll() {
        return billetRepository.findAll().stream()
                .map(billet -> new BilletDto(billet.getId(), billet.getNom(), billet.getPrenom(), billet.getSoiId()))
                .collect(Collectors.toList());
    }

    public void delete(Long id) {
        billetRepository.deleteById(id);
    }
}