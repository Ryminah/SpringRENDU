package com.application.controllers;

import com.application.dtos.BilletDto;
import com.application.services.BilletService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/billets")
public class BilletController {

    private final BilletService billetService;

    public BilletController(BilletService billetService) {
        this.billetService = billetService;
    }

    @PostMapping
    public BilletDto create(@RequestBody BilletDto billetDto) {
        return billetService.create(billetDto);
    }

    @GetMapping("/{id}")
    public BilletDto findById(@PathVariable Long id) {
        return billetService.findById(id);
    }

    @GetMapping
    public List<BilletDto> findAll() {
        return billetService.findAll();
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        billetService.delete(id);
    }
}