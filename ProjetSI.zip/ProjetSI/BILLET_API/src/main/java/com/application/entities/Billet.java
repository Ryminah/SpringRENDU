package com.application.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "Billet_bil")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Billet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "bil_id")
    private Long id;

    @Column(name = "bil_nom")
    private String nom;

    @Column(name = "bil_prenom")
    private String prenom;

    @Column(name = "soi_id")
    private Long soiId;
}