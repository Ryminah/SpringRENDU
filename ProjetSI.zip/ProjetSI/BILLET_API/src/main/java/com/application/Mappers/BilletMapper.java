package com.application.Mappers;

import com.application.dtos.BilletDto;
import com.application.entities.Billet;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface BilletMapper {

    BilletDto toBilletDTO(Billet billet);

    Billet toBillet(BilletDto billetDTO);

    List<BilletDto> toBilletDTOList(List<Billet> billetList);

    List<Billet> toBilletList(List<BilletDto> billetDTOList);
}
