package com.application.controllers;

import com.application.dtos.ConcertDto;
import com.application.services.ConcertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/concerts")
public class ConcertController {
    @Autowired
    private ConcertService concertService;

    @GetMapping
    public List<ConcertDto> getAllConcerts() {
        return concertService.getAllConcerts();
    }

    @GetMapping("/{id}")
    public ConcertDto getConcertById(@PathVariable int id) {
        return concertService.getConcertById(id);
    }

    @PostMapping
    public ConcertDto createConcert(@RequestBody ConcertDto concertConDto) {
        return concertService.createConcert(concertConDto);
    }

    @PutMapping("/{id}")
    public ConcertDto updateConcert(@PathVariable int id, @RequestBody ConcertDto concertConDto) {
        return concertService.updateConcert(id, concertConDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteConcert(@PathVariable int id) {
        concertService.deleteConcert(id);
        return ResponseEntity.noContent().build();
    }
}
