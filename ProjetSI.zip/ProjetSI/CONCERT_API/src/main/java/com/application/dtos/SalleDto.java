package com.application.dtos;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SalleDto {

    private Long id;
    private String nom;
    private String adresse;
    private Integer capacite;
    private String gestion;
    private String asso;
    private String president;
}