package com.application.dtos;

import lombok.*;

import lombok.Data;

@Data
public class SoireeDto {
    private Long id;
    private String nom;
    private Long salleId;
}