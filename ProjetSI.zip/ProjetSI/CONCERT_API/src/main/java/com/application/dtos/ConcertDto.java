package com.application.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConcertDto {
    private int id;
    private LocalDateTime debut;
    private LocalDateTime fin;
    private int soiId;
    private int grpId;
}