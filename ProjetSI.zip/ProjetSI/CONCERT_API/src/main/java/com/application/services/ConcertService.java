package com.application.services;


import com.application.Mappers.ConcertMapper;
import com.application.dtos.ConcertDto;
import com.application.entities.Concert;
import com.application.repositories.ConcertRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ConcertService {

    private ConcertRepository concertRepository;


    private ConcertMapper concertMapper;

    public List<ConcertDto> getAllConcerts() {
        return concertRepository.findAll().stream()
                .map(concertMapper::entityToDto)
                .collect(Collectors.toList());
    }

    public ConcertDto getConcertById(int id) {
        Concert concert = concertRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Concert with id " + id + " not found"));
        return concertMapper.entityToDto(concert);
    }

    public ConcertDto createConcert(ConcertDto concertDto) {
        Concert concert = concertMapper.dtoToEntity(concertDto);
        concert = concertRepository.save(concert);
        return concertMapper.entityToDto(concert);
    }

    public ConcertDto updateConcert(int id, ConcertDto concertDto) {
        Concert concert = concertRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Concert with id " + id + " not found"));
        concert.setDebut(concertDto.getDebut());
        concert.setFin(concertDto.getFin());
        concert.setSoiId(concertDto.getSoiId());
        concert.setGrpId(concertDto.getGrpId());
        concert = concertRepository.save(concert);
        return concertMapper.entityToDto(concert);
    }

    public void deleteConcert(int id) {
        concertRepository.deleteById(id);
    }
}