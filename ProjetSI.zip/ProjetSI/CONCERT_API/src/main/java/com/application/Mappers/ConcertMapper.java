package com.application.Mappers;

import com.application.dtos.ConcertDto;
import com.application.entities.Concert;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Component;

@Mapper(componentModel = "spring")
public interface ConcertMapper {

    @Mapping(target = "id", ignore = true)
    Concert dtoToEntity(ConcertDto concertConDto);

    ConcertDto entityToDto(Concert concertConEntity);

}
