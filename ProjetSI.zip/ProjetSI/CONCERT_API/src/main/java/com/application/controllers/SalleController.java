package com.application.controllers;

import com.application.dtos.SalleDto;
import com.application.services.SalleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/salles")
public class SalleController {

    private final SalleService salleService;

    public SalleController(SalleService salleService) {
        this.salleService = salleService;
    }

    @GetMapping("/{id}")
    public SalleDto getSalleById(@PathVariable Long id) {
        return salleService.getSalleById(id);
    }

    @GetMapping
    public List<SalleDto> getAllSalles() {
        return salleService.getAllSalles();
    }

    @PostMapping
    public SalleDto createSalle(@RequestBody SalleDto salleDto) {
        return salleService.createSalle(salleDto);
    }

    @PutMapping("/{id}")
    public SalleDto updateSalle(@PathVariable Long id, @RequestBody SalleDto salleDto) {
        return salleService.updateSalle(id, salleDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSalle(@PathVariable Long id) {
        return salleService.deleteSalle(id);
    }
}