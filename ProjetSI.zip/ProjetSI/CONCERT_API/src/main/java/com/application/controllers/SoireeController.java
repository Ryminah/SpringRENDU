package com.application.controllers;

import java.util.List;

import com.application.dtos.SoireeDto;
import com.application.services.SoireeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@CrossOrigin
@RestController
@RequestMapping("/soirees")
public class SoireeController {
    @Autowired
    private SoireeService soireeService;

    @GetMapping
    public List<SoireeDto> getAllSoirees() {
        List<SoireeDto> soirees = soireeService.getAllSoirees();
        return soirees;
    }

    @GetMapping("/{id}")
    public SoireeDto getSoireeById(@PathVariable Long id) {
        SoireeDto soireeDto = soireeService.getSoireeById(id);
        return soireeDto;
    }

    @PostMapping
    public SoireeDto createSoiree(@RequestBody SoireeDto soireeDto) {
        SoireeDto createdSoireeDto = soireeService.createSoiree(soireeDto);
        return createdSoireeDto;
    }

    @PutMapping("/{id}")
    public SoireeDto updateSoiree(@PathVariable Long id, @RequestBody SoireeDto soireeDto) {
        SoireeDto updatedSoireeDto = soireeService.updateSoiree(id, soireeDto);
        return updatedSoireeDto;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSoireeById(@PathVariable Long id) {
        soireeService.deleteSoireeById(id);
        return ResponseEntity.noContent().build();
    }
}