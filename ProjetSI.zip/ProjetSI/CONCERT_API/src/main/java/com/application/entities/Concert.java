package com.application.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "Concert_con")
@Data
@NoArgsConstructor
public class Concert {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "con_id")
    private int id;

    @Column(name = "con_debut")
    private LocalDateTime debut;

    @Column(name = "con_fin")
    private LocalDateTime fin;

    @Column(name = "soi_id")
    private int soiId;

    @Column(name = "grp_id")
    private int grpId;

    public Concert(LocalDateTime debut, LocalDateTime fin, int soiId, int grpId) {
        this.debut = debut;
        this.fin = fin;
        this.soiId = soiId;
        this.grpId = grpId;
    }
}