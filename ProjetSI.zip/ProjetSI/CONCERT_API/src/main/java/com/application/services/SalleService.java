package com.application.services;

import com.application.Mappers.SalleMapper;
import com.application.dtos.SalleDto;
import com.application.entities.Salle;
import com.application.repositories.SalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class SalleService {

    private final SalleRepository salleRepository;
    private final SalleMapper salleMapper;

    @Autowired
    public SalleService(SalleRepository salleRepository, SalleMapper salleMapper) {
        this.salleRepository = salleRepository;
        this.salleMapper = salleMapper;
    }

    public List<SalleDto> getAllSalles() {
        List<Salle> salles = salleRepository.findAll();
        return salles.stream()
                .map(salleMapper::salleToDto)
                .collect(Collectors.toList());
    }

    public SalleDto getSalleById(Long id) {
        Salle salle = salleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Salle not found with id " + id));
        return salleMapper.salleToDto(salle);
    }

    public SalleDto createSalle(SalleDto salleDto) {
        Salle salle = salleMapper.dtoToSalle(salleDto);
        salle.setId(null);
        salle = salleRepository.save(salle);
        return salleMapper.salleToDto(salle);
    }

    public SalleDto updateSalle(Long id, SalleDto salleDto) {
        Salle salle = salleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Salle not found with id " + id));
        salle.setNom(salleDto.getNom());
        salle.setAdresse(salleDto.getAdresse());
        salle.setCapacite(salleDto.getCapacite());
        salle.setGestion(salleDto.getGestion());
        salle.setAsso(salleDto.getAsso());
        salle.setPresident(salleDto.getPresident());
        salle = salleRepository.save(salle);
        return salleMapper.salleToDto(salle);
    }

    public ResponseEntity<Void> deleteSalle(Long id) {
        Salle salle = salleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Salle not found with id " + id));
        salleRepository.delete(salle);
        return null;
    }
}