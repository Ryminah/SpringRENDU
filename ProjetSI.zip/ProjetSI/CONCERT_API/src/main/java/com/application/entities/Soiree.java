package com.application.entities;

import javax.persistence.*;

import lombok.Data;

@Entity
@Data
@Table(name = "Soiree_soi")
public class Soiree {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "soi_id")
    private Long id;
    @Column(name = "soi_nom")
    private String nom;
    @Column(name = "sal_id")
    private Long salleId;
}