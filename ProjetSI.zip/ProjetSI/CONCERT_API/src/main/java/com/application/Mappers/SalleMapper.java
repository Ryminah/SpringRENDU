package com.application.Mappers;

import com.application.dtos.SalleDto;
import com.application.entities.Salle;
import org.mapstruct.Mapper;
@Mapper(componentModel = "spring")
public interface SalleMapper {

    SalleDto salleToDto(Salle salle);

    Salle dtoToSalle(SalleDto salleDto);
}