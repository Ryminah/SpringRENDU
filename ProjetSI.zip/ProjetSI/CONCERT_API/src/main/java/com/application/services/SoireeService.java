package com.application.services;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.application.dtos.SoireeDto;
import com.application.entities.Soiree;
import com.application.repositories.SoireeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class SoireeService {
    @Autowired
    private SoireeRepository soireeRepository;

    public List<SoireeDto> getAllSoirees() {
        List<Soiree> soireeEntities = soireeRepository.findAll();
        return soireeEntities.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    public SoireeDto getSoireeById(Long id) {
        Optional<Soiree> optionalSoiree = soireeRepository.findById(id);
        if (optionalSoiree.isPresent()) {
            return mapToDto(optionalSoiree.get());
        } else {
            return null;
        }
    }

    public SoireeDto createSoiree(SoireeDto soireeDto) {
        Soiree soiree = mapToEntity(soireeDto);
        Soiree createdSoiree = soireeRepository.save(soiree);
        return mapToDto(createdSoiree);
    }

    public SoireeDto updateSoiree(Long id, SoireeDto soireeDto) {
        Optional<Soiree> optionalSoiree = soireeRepository.findById(id);
        if (optionalSoiree.isPresent()) {
            Soiree soiree = optionalSoiree.get();
            soiree.setNom(soireeDto.getNom());
            soiree.setSalleId(soireeDto.getSalleId());
            Soiree updatedSoiree = soireeRepository.save(soiree);
            return mapToDto(updatedSoiree);
        } else {
            return null;
        }
    }

    public void deleteSoireeById(Long id) {
        soireeRepository.deleteById(id);
    }

    private SoireeDto mapToDto(Soiree soiree) {
        SoireeDto soireeDto = new SoireeDto();
        soireeDto.setId(soiree.getId());
        soireeDto.setNom(soiree.getNom());
        soireeDto.setSalleId(soiree.getSalleId());
        return soireeDto;
    }

    private Soiree mapToEntity(SoireeDto soireeDto) {
        Soiree soiree = new Soiree();
        soiree.setNom(soireeDto.getNom());
        soiree.setSalleId(soireeDto.getSalleId());
        return soiree;
    }
}