package com.application.entities;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "Salle_sal")
public class Salle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sal_id")
    private Long id;

    @Column(name = "sal_nom")
    private String nom;

    @Column(name = "sal_adresse")
    private String adresse;

    @Column(name = "sal_capacite")
    private Integer capacite;

    @Column(name = "sal_gestion")
    private String gestion;

    @Column(name = "sal_asso")
    private String asso;

    @Column(name = "sal_president")
    private String president;
}