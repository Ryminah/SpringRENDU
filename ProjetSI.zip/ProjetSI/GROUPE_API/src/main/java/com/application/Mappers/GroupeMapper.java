package com.application.Mappers;

import com.application.dtos.GroupeDto;
import com.application.entities.Groupe;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface GroupeMapper {

    GroupeMapper INSTANCE = Mappers.getMapper(GroupeMapper.class);

    @Mapping(target = "id", source = "groupeDto.id")
    Groupe dtoToEntity(GroupeDto groupeDto);

    @Mapping(target = "id", source = "groupe.id")
    GroupeDto entityToDto(Groupe groupe);
}