package com.application.controllers;

import com.application.dtos.ArtisteDto;
import com.application.services.ArtisteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/artistes")
public class ArtisteController {

    @Autowired
    private ArtisteService artisteService;

    @GetMapping
    public List<ArtisteDto> getAllArtistes() {
        List<ArtisteDto> artistes = artisteService.getAllArtistes();
        return artistes;
    }

    @GetMapping("/{id}")
    public ArtisteDto getArtisteById(@PathVariable("id") int id) {
        ArtisteDto artiste = artisteService.getArtisteById((long) id);
        return artiste;
    }

    @PostMapping
    public ArtisteDto createArtiste(@RequestBody ArtisteDto artisteDto) {
        ArtisteDto createdArtiste = artisteService.createArtiste(artisteDto);
        return createdArtiste;
    }

    @PutMapping("/{id}")
    public ArtisteDto updateArtiste(@PathVariable("id") int id, @RequestBody ArtisteDto artisteDto) {
        ArtisteDto updatedArtiste = artisteService.updateArtiste((long) id, artisteDto);
        return updatedArtiste;
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteArtiste(@PathVariable("id") int id) {
        artisteService.deleteArtiste((long) id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}