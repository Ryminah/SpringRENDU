package com.application.services;

import com.application.Mappers.ArtisteMapper;
import com.application.dtos.ArtisteDto;
import com.application.entities.Artiste;
import com.application.repositories.ArtisteRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ArtisteService {

    private ArtisteRepository artisteRepository;
    private ArtisteMapper artisteMapper;

    public List<ArtisteDto> getAllArtistes() {
        List<Artiste> artistes = artisteRepository.findAll();
        return artistes.stream()
                .map(artisteMapper::entityToDto)
                .collect(Collectors.toList());
    }

    public ArtisteDto getArtisteById(Long id) {
        Artiste artiste = artisteRepository.findById(id).orElse(null);
        if (artiste == null) {
            return null;
        }
        return artisteMapper.entityToDto(artiste);
    }

    public ArtisteDto createArtiste(ArtisteDto artisteDto) {
        Artiste artiste = artisteMapper.dtoToEntity(artisteDto);
        artiste = artisteRepository.save(artiste);
        return artisteMapper.entityToDto(artiste);
    }

    public ArtisteDto updateArtiste(Long id, ArtisteDto artisteDto) {
        Artiste artiste = artisteRepository.findById(id).orElse(null);
        if (artiste == null) {
            return null;
        }
        artiste.setNom(artisteDto.getNom());
        artiste.setPrenom(artisteDto.getPrenom());
        artiste.setPseudo(artisteDto.getPseudo());
        artiste.setVille(artisteDto.getVille());
        artiste.setAge(artisteDto.getAge());
        artiste.setGroupeId(artisteDto.getGroupeId());
        artiste = artisteRepository.save(artiste);
        return artisteMapper.entityToDto(artiste);
    }

    public void deleteArtiste(Long id) {
        artisteRepository.deleteById(id);
    }
}