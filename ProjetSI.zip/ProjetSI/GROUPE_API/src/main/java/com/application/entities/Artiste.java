package com.application.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "Artiste_art")
@Data
@NoArgsConstructor
public class Artiste {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "art_id")
    private Long id;
    @Column(name = "art_nom")
    private String nom;
    @Column(name = "art_prenom")
    private String prenom;
    @Column(name = "art_pseudo")
    private String pseudo;
    @Column(name = "art_ville")
    private String ville;
    @Column(name = "art_age")
    private int age;
    @Column(name = "grp_id")
    private Long groupeId;
}