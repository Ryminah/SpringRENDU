package com.application.dtos;

import lombok.Data;

@Data
public class GroupeDto {
    private Long id;
    private String nom;
}