package com.application.controllers;

import com.application.dtos.GroupeDto;
import com.application.services.GroupeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/groupes")
public class GroupeController {

    @Autowired
    private GroupeService groupeService;

    @GetMapping
    public ResponseEntity<List<GroupeDto>> getAllGroupes() {
        List<GroupeDto> groupes = groupeService.getAllGroupes();
        return ResponseEntity.ok(groupes);
    }

    @GetMapping("/{id}")
    public ResponseEntity<GroupeDto> getGroupeById(@PathVariable Long id) {
        GroupeDto groupeDto = groupeService.getGroupeById(id);
        return ResponseEntity.ok(groupeDto);
    }

    @PostMapping
    public ResponseEntity<GroupeDto> createGroupe(@RequestBody GroupeDto groupeDto) {
        GroupeDto createdGroupeDto = groupeService.createGroupe(groupeDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdGroupeDto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<GroupeDto> updateGroupe(@PathVariable Long id, @RequestBody GroupeDto groupeDto) {
        GroupeDto updatedGroupeDto = groupeService.updateGroupe(id, groupeDto);
        return ResponseEntity.ok(updatedGroupeDto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGroupe(@PathVariable Long id) {
        groupeService.deleteGroupe(id);
        return ResponseEntity.noContent().build();
    }
}
