package com.application.Mappers;

import com.application.dtos.ArtisteDto;
import com.application.entities.Artiste;
import org.mapstruct.Mapper;
@Mapper(componentModel = "spring")
public interface ArtisteMapper {
    ArtisteDto entityToDto(Artiste artiste);

    Artiste dtoToEntity(ArtisteDto artisteDto);
}