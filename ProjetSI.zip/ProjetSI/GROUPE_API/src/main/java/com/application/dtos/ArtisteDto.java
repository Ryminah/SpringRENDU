package com.application.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ArtisteDto {
    private Long id;
    private String nom;
    private String prenom;
    private String pseudo;
    private String ville;
    private int age;
    private Long groupeId;
}