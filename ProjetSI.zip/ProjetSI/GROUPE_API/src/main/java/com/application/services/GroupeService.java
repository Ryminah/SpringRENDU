package com.application.services;

import com.application.Mappers.GroupeMapper;
import com.application.dtos.GroupeDto;
import com.application.entities.Groupe;
import com.application.repositories.GroupeRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class GroupeService {

    private GroupeRepository groupeRepository;

    private GroupeMapper groupeMapper;

    public List<GroupeDto> getAllGroupes() {
        return groupeRepository.findAll().stream()
                .map(groupeMapper::entityToDto)
                .collect(Collectors.toList());
    }

    public GroupeDto getGroupeById(Long id) {
        Groupe groupe = groupeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Groupe with id " + id + " not found"));
        return groupeMapper.entityToDto(groupe);
    }

    public GroupeDto createGroupe(GroupeDto groupeDto) {
        Groupe groupe = groupeMapper.dtoToEntity(groupeDto);
        groupe = groupeRepository.save(groupe);
        return groupeMapper.entityToDto(groupe);
    }

    public GroupeDto updateGroupe(Long id, GroupeDto groupeDto) {
        Groupe groupe = groupeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Groupe with id " + id + " not found"));
        groupe.setNom(groupeDto.getNom());
        groupe = groupeRepository.save(groupe);
        return groupeMapper.entityToDto(groupe);
    }

    public void deleteGroupe(Long id) {
        groupeRepository.deleteById(id);
    }
}
